/**
* $Author: MahrTh $
* $Rev: 122 $
* $Date: 2015-03-22 10:50:38 +0100 (So, 22. Mär 2015) $
* OPR-Praktikum: Aufgabe 1_Grundlagen/02_Kapselung/Flugkurve02: Variante 2
*/
#include "AbbildungGnuplot.h"
#include "Datensatz.h"
using namespace std;

int main()
{
	Datensatz datensatz;
	for(int x=0; x<=10; x++)
	{
		datensatz.hinzufuegen(x,x*x);
	}
	datensatz.anzeigen("Demo","x","y");
}

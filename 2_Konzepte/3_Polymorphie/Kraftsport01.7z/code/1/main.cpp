/**
* $Author: MahrTh $
* $Rev: 351 $
* $Date: 2017-04-18 18:13:29 +0200 (Di, 18. Apr 2017) $
*/
#include "Bankdruecken.h"
#include "EnergieFormatJoule.h"
#include "EnergieFormatSchokolade.h"
#include "PrueffolgeSport.h"
#include "Sportler.h"
#include "Uebung.h"
using namespace std;

void prueffolge()
{
	PrueffolgeSport prueffolge;
	prueffolge.ausfuehren();
}

void beispiel1()
{
	Sportler hugo("Hugo", 85, 0.8);
	cout << "Anwendungsbeispiel 1:\n" << hugo.text() << endl;
	Bankdruecken geraetBankdruecken;
	int anzahlSaetze = 3;
	int anzahlWiederholungenProSatz = 10;
	double gewicht = 100;
	Uebung bankdruecken(&hugo, &geraetBankdruecken, anzahlSaetze, anzahlWiederholungenProSatz, gewicht);
	bankdruecken.ausfuehren(&cout);		
	EnergieFormatJoule energieFormatJoule;
	EnergieFormatSchokolade energieFormatSchokolade;
	cout << "Energieumsatz: " << energieFormatJoule.format(hugo.energieUmsatz()) << " (entspricht " << energieFormatSchokolade.format(hugo.energieUmsatz()) << ")";
}

void beispiel2()
{
	Sportler clark("Clark Kent", 85, 0.8);
	cout << "Anwendungsbeispiel 2:\n" << clark.text() << endl;
	Bankdruecken geraetBankdruecken;
	int anzahlSaetze = 3;

	// Diese beiden Parameter sind so einzustellen, dass Clark Kent 1 Tafel Schokolade "verbrennt":
	const int anzahlWiederholungenProSatz = 1;
	const double gewicht = 1;

	Uebung extremBankdruecken(&clark, &geraetBankdruecken, anzahlSaetze, anzahlWiederholungenProSatz, gewicht);
	extremBankdruecken.ausfuehren(&cout);	
	EnergieFormatJoule energieFormatJoule;
	EnergieFormatSchokolade energieFormatSchokolade;
	cout << "Energieumsatz: " << energieFormatJoule.format(clark.energieUmsatz()) << " (entspricht " << energieFormatSchokolade.format(clark.energieUmsatz()) << ")";
}

int main()
{
	beispiel1();
	cout << endl << endl;
	beispiel2();
	cout << "\n\nPrüffolge:\n";
	prueffolge();
}


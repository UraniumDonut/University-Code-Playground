/**
* $Author: MahrTh $
* $Rev: 351 $
* $Date: 2017-04-18 18:13:29 +0200 (Di, 18. Apr 2017) $
*/
#pragma once
#include "Prueffolge.h"
#include "Sportler.h"
#include "Bankdruecken.h"
#include "Klimmzug.h"

class PrueffolgeSport : public Prueffolge
{
public:

	PrueffolgeSport();

private:

	static void pruefungSportler();
	static void pruefungSportlerAusgabe();
	static void pruefungBankdruecken();
	static void pruefungBankdrueckenAusgabe();
	static void pruefungKlimmzug();
	static void pruefungKlimmzugAusgabe();
	static void pruefungWiederholungAusfuehrenBankdruecken();
	static void pruefungWiederholungAusfuehrenKlimmzug();
	static void pruefungUebungSatz();
	static void pruefungUebungBankdruecken();
	static void pruefungUebungKlimmzug();
	static void pruefungTrainingJoule();
	static void pruefungTrainingSchokolade();
	
	static const Sportler SPORTLER;
	static const Bankdruecken BANKDRUECKEN;
	static const Klimmzug KLIMMZUG;
};

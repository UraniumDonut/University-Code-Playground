/**
 * OPR-Praktikum SS 2013
 * Aufgabe 8
 * @author Thomas Mahr
 */

#include "audio.h"
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iostream>
#include <sstream>
using namespace std;

bool Audio::aktiviereKonsolenausgabe = true;

Audio::Audio(unsigned long int laenge) : laenge(laenge)
{
	Audio::log("Audio()\n");
	amplitude = new int[laenge];  
}

Audio::Audio(const Audio& a) : laenge(a.laenge) 
{
	Audio::log("Audio(const Audio&)\n");
	amplitude = new int[laenge]; 
	memcpy(amplitude,a.amplitude,laenge*sizeof(int)); 
}

Audio::~Audio()  
{
	Audio::log("~Audio()\n");
	if(amplitude!=nullptr)   
	{
		delete[] amplitude;
	}
}

void Audio::zuweisung(const Audio& a)  
{
	if(this!=&a)
	{
		Audio::log("operator=(Audio&)\n");
		if(amplitude!=nullptr)  
		{
			delete[] amplitude;
		}
		laenge = a.laenge;
		amplitude = new int[laenge]; 
		memcpy(amplitude,a.amplitude,laenge*sizeof(int)); 	
	}
}

std::string Audio::text() const 
{
	int i=0;
	std::stringstream s;
	for(unsigned long int x=0; x<laenge; x++) 
	{
		s << amplitude[i++] << " ";
	}
	return s.str();
}

Audio* Audio::erzeugeRauschSignal(unsigned long int laenge)
{
	Audio* audio = new Audio(laenge);
	
	srand(time(0));
	
	for(unsigned long int i=0; i<laenge; i++)
	{
		const int MAX_AMP = 1000;
		audio->amplitude[i] = rand() % (2*MAX_AMP+1) - MAX_AMP;
	}
	
	return audio;
}

/**
 * OPR-Praktikum SS 2012
 * Aufgabe 9
 * @author Thomas Mahr
 */

#include "PrueffolgeAtomkern.h"

int main() 
{
	PrueffolgeAtomkern prueffolgeAtomkern;
	prueffolgeAtomkern.ausfuehren();
}

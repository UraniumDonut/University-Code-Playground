/**
 * OPR-Praktikum SS 2012
 * Aufgabe 9
 * @author Thomas Mahr
 */

#include "PrueffolgeReaktor.h"

int main() 
{
	PrueffolgeReaktor prueffolgeReaktor;
	prueffolgeReaktor.ausfuehren();
}
